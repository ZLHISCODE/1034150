﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oracle.ManagedDataAccess.Client;
using System.Collections.Generic;
using ZLPubInterface;

namespace ZLTestPubinterfaceNet
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            clsInterface objInterface = new clsInterface();
            string strError = null;
            textBox1.Text ="测试过期授权码";
            //OracleConnection connTmp = objInterface.GetConnection("D04DD6969FE844", "127.0.0.1:1521/TESTBASE", out  strError);
            //if (connTmp.State == ConnectionState.Closed)
            //{
            //    textBox1.Text = textBox1.Text + "\r\n----过期授权码校验成功:" + strError;
            //}
            //else {
            //    textBox1.Text = textBox1.Text + "\r\n----过期授权码校验失败";
            //}
            //textBox1.Text = textBox1.Text + "\r\n 测试正常授权码";
            //connTmp = objInterface.GetConnection("8D0C1DB4134D43", "127.0.0.1:1521/TESTPARA", out  strError);
            //if (connTmp.State == ConnectionState.Closed)
            //{
            //    textBox1.Text = textBox1.Text + "\r\n----正常授权码校验失败:" + strError;
            //}
            //else
            //{
            //    textBox1.Text = textBox1.Text + "\r\n----正常授权码校验成功";
            //}
            //textBox1.Text = textBox1.Text + "\r\n 测试IP/SERVER";
            //connTmp = objInterface.GetConnection("8D0C1DB4134D43", "127.0.0.1/TESTPARA", out  strError);
            //if (connTmp.State == ConnectionState.Closed)
            //{
            //    textBox1.Text = textBox1.Text + "\r\n----IP/SERVER校验失败:" + strError;
            //}
            //else
            //{
            //    textBox1.Text = textBox1.Text + "\r\n----IP/SERVER校验成功";
            //}
            //textBox1.Text = textBox1.Text + "\r\n 测试未生效授权码";
            //connTmp = objInterface.GetConnection("0C38E1E89B8C44", "127.0.0.1/TESTPARA", out  strError);
            //if (connTmp.State == ConnectionState.Closed)
            //{
            //    textBox1.Text = textBox1.Text + "\r\n----未生效授权码校验成功:" + strError;
            //}
            //else
            //{
            //    textBox1.Text = textBox1.Text + "\r\n----未生效授权码校验失败";
            //}
            //textBox1.Text = textBox1.Text + "\r\n 测试停用授权码";
            //connTmp = objInterface.GetConnection("B44E608078FF47", "127.0.0.1/TESTPARA", out  strError);
            //if (connTmp.State == ConnectionState.Closed)
            //{
            //    textBox1.Text = textBox1.Text + "\r\n----停用授权码校验成功:" + strError;
            //}
            //else
            //{
            //    textBox1.Text = textBox1.Text + "\r\n----停用授权码校验失败";
            //}
            //string strUnit = null;
            //strUnit = objInterface.GetUnitName("B44E608078FF47", "127.0.0.1/TESTPARA", out  strError);
            //if (strUnit != null)
            //{
            //    textBox1.Text = textBox1.Text + "\r\n----GetUnitName校验成功:" + strUnit;
            //}
            //else
            //{
            //    textBox1.Text = textBox1.Text + "\r\n----GetUnitName校验失败:" + strError;
            //}
            //textBox1.Text = textBox1.Text + "\r\n 测试正常授权码";
            //connTmp = objInterface.GetConnection("8D0C1DB4134D43", "127.0.0.1:1521/TESTPARA", out  strError);
            //if (connTmp.State == ConnectionState.Closed)
            //{
            //    textBox1.Text = textBox1.Text + "\r\n----正常授权码校验失败:" + strError;
            //}
            //else
            //{
            //    textBox1.Text = textBox1.Text + "\r\n----正常授权码校验成功";
            //}
            //strUnit = objInterface.GetUnitName("8D0C1DB4134D43", connTmp, out  strError);
            //if (strUnit != null)
            //{
            //    textBox1.Text = textBox1.Text + "\r\n----GetUnitName(连接方式1)校验成功:" + strUnit;
            //}
            //else
            //{
            //    textBox1.Text = textBox1.Text + "\r\n----GetUnitName(连接方式1)校验失败:" + strError;
            //}
            string strUnit = objInterface.GetPassword("A0CFBE945BC548", "127.0.0.1:1521/TESTBASE", "ZLHIS",out strError,-1);
            if (strUnit != null)
            {
                textBox1.Text = textBox1.Text + "\r\n----GetUnitName(连接方式2)校验成功:" + strUnit;
            }
            else
            {
                textBox1.Text = textBox1.Text + "\r\n----GetUnitName(连接方式2)校验失败:" + strError;
            }
//    strError = ""
//    Set cnnTmp = objInterface.GetConnection("8D0C1DB4134D43", "TESTPARA", , strError)
//    trTestResult.AssertEqualsLong cnnTmp.State, adStateOpen, "正常授权码校验失败：" & strError
    
//    strError = ""
//    Set cnnTmp = objInterface.GetConnection("0C38E1E89B8C44", "TESTPARA", , strError)
//    trTestResult.AssertEqualsLong cnnTmp.State, adStateClosed, "未生效授权码校验失败：" & strError
    
//    strError = ""
//    Set cnnTmp = objInterface.GetConnection("B44E608078FF47", "TESTPARA", , strError)
//    trTestResult.AssertEqualsLong cnnTmp.State, adStateClosed, "停用授权码校验失败：" & strError
    
//    strError = ""
//    Set cnnTmp = objInterface.GetConnection("8D0C1DB4134D43", "127.0.0.1/TESTPARA", , strError)
//    trTestResult.AssertEqualsLong cnnTmp.State, adStateOpen, "IP/SERVER方式校验失败：" & strError
    
//    strError = ""
//    Set cnnTmp = objInterface.GetConnection("8D0C1DB4134D43", "127.0.0.1:1521/TESTPARA", , strError)
//    trTestResult.AssertEqualsLong cnnTmp.State, adStateOpen, "IP:Port/SERVER方式校验失败：" & strError
    
//    strError = ""
//    trTestResult.Assert objInterface.GetUnitName("8D0C1DB4134D43", "127.0.0.1:1521/TESTPARA", strError) <> "", "GetUnitName测试失败：" & strError
    
//    strError = ""
//    trTestResult.Assert objInterface.GetUnitName("8D0C1DB4134D43", cnnTmp, strError) <> "", "GetUnitName(传连接)测试失败：" & strError
//    On Error Resume Next
//    strSQL = "Select Count(1) 计数 from zlsystems"
//    Set rsTmp = OpenSQLRecord(cnnTmp, strSQL, "中联软件")
//    trTestResult.AssertNotNull rsTmp, "读取SQL失败" & Err.Description
//    Exit Sub
//ErrH:
//    trTestResult.AssertNotNull objInterface, "ZLPubInterface.clsPubInterface创建失败：" & Err.Description
//    Err.Raise 1, "TCPUBInterface", "出现异常:(" & Err.Number & ")" & Err.Description
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
