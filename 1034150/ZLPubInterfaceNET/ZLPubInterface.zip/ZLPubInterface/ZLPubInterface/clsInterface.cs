﻿using System;
using System.Data;
using Oracle.ManagedDataAccess.Client;
using System.Collections.Generic;

namespace ZLPubInterface
{
    public sealed class clsInterface
    {
        private string G_UA_PWD = "FA74C8A530DE7E088B1ACA673DD6297D";
        private string G_UA_KEY ="0016FDE250354FA9A4BA45433DBCC35D";
        private string G_INTERFACE_KEY = "EBA1D9B8CCCB4FD0804672DEDB222CFB";
        private string G_APP_KEY = "FD304782E75C41FDB14CB7A92A8A0B97";
        private string G_PASSWORD_KEY = "3357F1F2CA0341A5B75DBA7F35666715";
        //'======================================================================================================================
        //'接口           GetConnection           验证三方接口的APPID与授权码，成功，则返回的连接为Open状态，否则为Closed状态
        //'返回值         Connection对象
        //'入参列表:
        //'参数名         类型                    说明
        //'Key            String                  三方接口授权码的明文
        //'Server         String                  三方接口要连接的服务器(IP:Port/SID)，Port为1521可以省略，此时格式为IP/SID
        //'strErrNote     String(Out)             返回错误信息
        //'======================================================================================================================
        public OracleConnection GetConnection(string strKey, string strServer, out string strErrNote ) 
        {
            strErrNote = null;
            clsDataBase zlDataBase=new clsDataBase();
            OracleConnection connReturn = new OracleConnection();
            using (OracleConnection connZLUA = zlDataBase.OraDBOpen(strServer, "ZLUA", ZLSM4.Sm4DecryptEcb("ZLSV2:" + G_UA_PWD, ZLSM4.GetGeneralAccountKey(G_UA_KEY))))
            {
                if (connZLUA.State != ConnectionState.Open)
                {
                    strErrNote = zlDataBase.GetErrNote();
                    return connReturn;
                }
                if (!CheckGrantKey(zlDataBase, strKey, out strErrNote))
                {
                    return connReturn;
                }
                string strPWD = GetZLInterfacePWD(zlDataBase, out strErrNote);
                if (strPWD == null)
                {
                    return connReturn;
                }
                clsDataBase zlDBInface = new clsDataBase();
                connReturn = zlDBInface.OraDBOpen(strServer, "ZLINTERFACE", strPWD);
                if (connZLUA.State != ConnectionState.Open)
                {
                    strErrNote = zlDataBase.GetErrNote();
                    return connReturn;
                }
            }
            return connReturn;
        }

        //'======================================================================================================================
        //'接口           GetUnitName             验证三方接口的授权码，成功返回单位名称，否则返回空串
        //'返回值         String
        //'入参列表:
        //'参数名         类型                    说明
        //'Key            String                  三方接口授权码的明文
        //'varServerOrConnection   String         三方接口要连接的服务器（可以直接指定IP:Port/SID）或者已经打开的连接对象
        //'strErrNote     String(Out,Optional)    返回错误信息
        //'======================================================================================================================
        public string GetUnitName(string strKey, object varServerOrConnection, out string strErrNote)
        {
            strErrNote = null;
            string strUnitName=null;
            OracleConnection  connTmp;
            clsDataBase zldb= new clsDataBase();
            if (varServerOrConnection.GetType() == typeof(string)) {
                connTmp = GetConnection(strKey, (string)varServerOrConnection, out strErrNote);
                if (connTmp.State != ConnectionState.Open)
                {
                    return strUnitName;
                }
                zldb.InitOracleConn(connTmp);
            }
            else if (varServerOrConnection.GetType() == typeof(OracleConnection))
            {   
                if(varServerOrConnection==null){
                    strErrNote = "传入的连接未实例化。";
                    return strUnitName;
                }else if (((OracleConnection) varServerOrConnection).State != ConnectionState.Open){
                    strErrNote = "传入的连接未实例化。";
                    return strUnitName;
                }else{
                    connTmp = (OracleConnection)varServerOrConnection;
                    zldb.InitOracleConn(connTmp);
                    if(! CheckGrantKey(zldb,strKey,out strErrNote)){
                        return strUnitName;
                    }
                }
            }
            string strSQL = "Select Max(内容) 内容 From zlRegInfo A Where a.项目 = :P_Item";
            OracleParameter[] parms = new OracleParameter[] { 
                new OracleParameter(":P_Item", OracleDbType.Varchar2)
            };
            parms[0].Value = "单位名称";
            DataTable dtTmp = zldb.ExecuteDataTable(strSQL, parms);
            if (zldb.ErrorNumber != 0)
            {
                strErrNote =zldb.GetErrNote();
                return strUnitName;
            }
            DataRow drTmp = dtTmp.Rows[0];
            strUnitName = (string)drTmp["内容"];
            if (strUnitName == null)
            {
                strErrNote ="缺失单位名称信息（登录服务器管理工具会自动重建）。";
            }
            return strUnitName;
        }
        //'======================================================================================================================
        //'接口           GetPassword             验证三方接口的授权码，成功传入用户的登录密码
        //'返回值         String
        //'入参列表:
        //'参数名         类型                    说明
        //'Key            String                  三方接口授权码的明文
        //'strUserName    String                  用户名称
        //'varServerOrConnection   String         三方接口要连接的服务器（可以直接指定IP:Port/SID）或者已经打开的连接对象
        //'strErrNote     String(Out,Optional)    返回错误信息
        //'======================================================================================================================
        public string GetPassword(string strKey, object varServerOrConnection, string strUserName, out string strErrNote, int lngSys = -1)
        {
            strErrNote = null;
            string strPassWord = null;
            OracleConnection connTmp;
            clsDataBase zldb = new clsDataBase();
            if (varServerOrConnection.GetType() == typeof(string))
            {
                connTmp = zldb.OraDBOpen((string)varServerOrConnection, "ZLUA", ZLSM4.Sm4DecryptEcb("ZLSV2:" + G_UA_PWD, ZLSM4.GetGeneralAccountKey(G_UA_KEY)));
                if (connTmp.State != ConnectionState.Open)
                {
                    return strPassWord;
                }
                zldb.InitOracleConn(connTmp);
            }
            else if (varServerOrConnection.GetType() == typeof(OracleConnection))
            {
                if (varServerOrConnection == null)
                {
                    strErrNote = "传入的连接未实例化。";
                    return strPassWord;
                }
                else if (((OracleConnection)varServerOrConnection).State != ConnectionState.Open)
                {
                    strErrNote = "传入的连接未实例化。";
                    return strPassWord;
                }
                else
                {
                    connTmp = (OracleConnection)varServerOrConnection;
                    zldb.InitOracleConn(connTmp);
                }
            }
            if (!CheckGrantKey(zldb, strKey, out strErrNote))
            {
                return strPassWord;
            }
            string strOwner = null;
            string strSQL =null;
            if( lngSys == -1){
                strSQL="Select a.所有者 From zlSystems A Where a.编号 In (100, 300, 400, 600, 2500) Order By a.编号";
            }else{
                strSQL="Select a.所有者 From zlSystems A Where a.编号 =:P_SYS";
            }
            OracleParameter[] parmsSys = new OracleParameter[] { 
                new OracleParameter(":P_SYS", OracleDbType.Int32)
            };
            parmsSys[0].Value = lngSys;
            DataTable dtTmpSys = zldb.ExecuteDataTable(strSQL, parmsSys);
            if (zldb.ErrorNumber != 0)
            {
                strErrNote = zldb.GetErrNote();
                return strPassWord;
            }
            if (dtTmpSys.Rows.Count == 0)
            {
                if (lngSys == -1)
                {
                    strErrNote = "当前数据库不存在上机人员表。";
                }
                else
                {
                    strErrNote = "当前系统不存在上机人员表。";
                }
                return strPassWord;
            }
            else
            {
                DataRow drTmpSys = dtTmpSys.Rows[0];
                strOwner = (string)drTmpSys["所有者"];
            }
            strSQL = "Select Max(登录密码) 登录密码 From " + strOwner + ".上机人员表 A Where a.用户名  = :P_USER";
            OracleParameter[] parms = new OracleParameter[] { 
                new OracleParameter(":P_USER", OracleDbType.Varchar2)
            };
            parms[0].Value = strUserName;
            DataTable dtTmp = zldb.ExecuteDataTable(strSQL, parms);
            if (zldb.ErrorNumber != 0)
            {
                strErrNote = zldb.GetErrNote();
                return strPassWord;
            }
            if (dtTmpSys.Rows.Count != 0)
            {
                DataRow drTmp = dtTmp.Rows[0];
                strPassWord = (string)drTmp["登录密码"];
                if (strPassWord != null)
                {
                    strPassWord = ZLSM4.Sm4DecryptEcb(strPassWord, ZLSM4.GetGeneralAccountKey(G_PASSWORD_KEY)); ;
                }
            }
            return strPassWord;
        }
        /// <summary>
        /// 检测授权码是否合法
        /// </summary>
        /// <param name="dbCur">当前数据的连接对象</param>
        /// <param name="strKey">授权码</param>
        /// <param name="strErrNote">错误信息</param>
        /// <returns>是否合法</returns>
        private bool CheckGrantKey(clsDataBase dbCur, string strKey, out string strErrNote) {
            strErrNote = null;
            string    strSQL= "Select Key, To_Char(Starttime, 'YYYY-MM-DD hh24:mi:ss') Starttime, To_Char(Stoptime, 'YYYY-MM-DD hh24:mi:ss') Stoptime,\n" +
                            "       To_Char(Sysdate, 'YYYY-MM-DD hh24:mi:ss') Curtime, NVL(State,0) State \n" + 
                            "From Zlinterface\n" + 
                            "Where Key=:P_Key";
            OracleParameter[] parms = new OracleParameter[] { 
                new OracleParameter(":P_Key", OracleDbType.Varchar2)
            };
            parms[0].Value = ZLSM4.Sm4EncryptEcb(strKey, ZLSM4.GetGeneralAccountKey(G_APP_KEY));
            DataTable dtTmp = dbCur.ExecuteDataTable(strSQL, parms);
            if (dbCur.ErrorNumber != 0) {
                strErrNote ="授权码校验失败" + dbCur.GetErrNote();
                return false;
            }
            if (dtTmp.Rows.Count == 0)
            {
                strErrNote = "无该授权码。";
                return false;
            }
            else {
                DataRow drTmp = dtTmp.Rows[0];
                if (int.Parse(drTmp["State"].ToString()) == 1)
                {
                    strErrNote = "授权码已经停用。";
                    return false;
                }
                else if (drTmp["Stoptime"] != DBNull.Value) { 
                    string strCur=(string)drTmp["Curtime"];
                    string strStart=(string)drTmp["Starttime"];
                    string strStop=(string)drTmp["Stoptime"];
                    if(string.Compare(strCur,strStart)<0){
                        strErrNote = "授权码尚未生效（生效时间：" + strStart + "）。";
                        return false;
                    }
                    else if (string.Compare(strCur, strStop) > 0)
                    {
                        strErrNote = "授权码已经过期（过期时间：" + strStop + "）。";
                        return false;
                    }
                    else {
                        return true;
                    }
                }
            }
            return true;
        }
        /// <summary>
        /// 获取ZLInterface用户密码
        /// </summary>
        /// <param name="dbCur">当前数据库对象</param>
        /// <param name="strErrNote">错误信息</param>
        /// <returns>zlinterface密码</returns>
        private string GetZLInterfacePWD(clsDataBase dbCur, out string strErrNote) {
            strErrNote = null;
            string strSQL = "Select Max(内容) 内容 From zlRegInfo A Where a.项目 = :P_Item";
            OracleParameter[] parms = new OracleParameter[] { 
                new OracleParameter(":P_Item", OracleDbType.Varchar2)
            };
            parms[0].Value = "三方接口密码";
            DataTable dtTmp = dbCur.ExecuteDataTable(strSQL, parms);
            if (dbCur.ErrorNumber != 0)
            {
                strErrNote ="获取ZLInterface密码获取失败失败（登录服务器管理工具三方授权管理进行账户修复）。" + dbCur.GetErrNote();
                return null;
            }

            DataRow drTmp = dtTmp.Rows[0];
            string strPWD = (string)drTmp["内容"];

            if (strPWD == null)
            {
                strErrNote = "三方接口密码获取失败（登录服务器管理工具三方授权管理进行账户修复）。";
                return null;
            }
            else
            {
                strPWD=ZLSM4. Sm4DecryptEcb(strPWD,ZLSM4.GetGeneralAccountKey(G_INTERFACE_KEY));
                if (strPWD == null){
                    strErrNote = "三方接口密码获取失败（登录服务器管理工具三方授权管理进行账户修复）。";
                    return null;
                }
            }
            return strPWD;
        }
        /// <summary>
        /// 字符串SM4加密
        /// </summary>
        /// <param name="strInput">需加密的字符串</param>      
        /// <returns>加密后的值,格式：ZLSV+版本号+:+加密后的字符串</returns>
        public string GetEncryptCommand(string strInput)
        {
            return ZLSM4.Sm4EncryptEcb(strInput);
        }
    }
}
